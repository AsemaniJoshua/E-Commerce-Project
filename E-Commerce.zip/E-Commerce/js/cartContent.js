async function waitingForBrowser() {
    await new Promise(resolve => {
        document.addEventListener("DOMContentLoaded", resolve);
    });
    console.log("Page loaded");
}

waitingForBrowser().then(() => {
    displayCartContent();
    removeItem();
});

// Getting customerProducts array from localStorage
const customerProducts = JSON.parse(localStorage.getItem("customerProducts"));
console.log(customerProducts);

// Getting Html Elements
const cart_content = document.getElementById("cart_content");
const displayTotal = document.getElementById("displayTotal");
const total = document.getElementById("total");




// Function to display cart content
function displayCartContent() {
    
    // Clearing previous content
    cart_content.innerHTML = "";

    // Setting total and quantity to 0
    total.innerHTML = "Total: $0";
    let totalPrice = 0;
    let quantity = 0;



    // Looping through customerProducts array
    customerProducts.forEach(product => {
        
        // Creating a new div element for each product
        cart_content.innerHTML += `
            <div class="card">
                <img src="${product.image}" alt="${product.name}">
                <div class="cart_item_details">
                    <h3>${product.name}</h3>
                    <p>Price: $${product.price}</p>
                    <button class="remove_btn" id="removeProduct${product.id}" data-id="${product.id}">Remove</button>
                </div>
            </div>
        `;

        // Adding price to total
        totalPrice += product.price;
    });

    // Displaying total
    total.innerHTML = `Total: $${totalPrice.toFixed(2)}`;
}

// Functionality for removeProductBtn
function removeItem(){
    customerProducts.forEach(product => {
        const removeProductId = `removeProduct${product.id}`;
        const removeProductBtn = document.getElementById(removeProductId);

        if(removeProductBtn){
            removeProductBtn.addEventListener("click", () => {
                customerProducts = customerProducts.remove(product);
                localStorage.setItem("customerProducts", JSON.stringify(customerProducts));
                console.log(`Product ${product.name} removed from cart.`);
                alert(`Product ${product.name} removed from cart.`);
                displayCartContent();
            });
        }
    });
}




    